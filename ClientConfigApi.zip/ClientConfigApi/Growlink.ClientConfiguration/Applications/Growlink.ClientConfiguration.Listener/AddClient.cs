﻿using Growlink.ClientConfiguration.Models.Models;
using Growlink.ClientConfiguration.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;

namespace Growlink.ClientConfiguration.Listener
{
    public class AddClient
    {
        private IClientConfigurationService ClientConfigurationService { get; }
        public AddClient(IClientConfigurationService clientConfigurationService)
        {
            ClientConfigurationService = clientConfigurationService;
        }

        [FunctionName("AddClient")]
        public IActionResult AddClientDetails(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                log.LogInformation("AddClient HTTP trigger function processed a request.");

                string requestBody = new StreamReader(req.Body).ReadToEnd();
                ClientConfig clientConfig = JsonConvert.DeserializeObject<ClientConfig>(requestBody);
                var response = ClientConfigurationService.InsertClientConfiguration(clientConfig);

                return new OkObjectResult(response);
            }
            catch (Exception ex) 
            {
                log.LogError($"Add Client API failed to process the request with Exception: {ex.StackTrace}");
                return new ObjectResult(new ObjectResult(ex.Message)
                {
                    StatusCode = 500
                });
            }
        }
    }
}
