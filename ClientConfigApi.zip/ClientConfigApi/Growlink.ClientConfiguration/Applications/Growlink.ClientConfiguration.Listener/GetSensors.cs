﻿using Growlink.ClientConfiguration.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Growlink.ClientConfiguration.Models.Models;
using Azure;

namespace Growlink.ClientConfiguration.Listener
{
    public class GetSensors
    {
        private IClientConfigurationService ClientConfigurationService { get; }
        public GetSensors(IClientConfigurationService clientConfigurationService)
        {
            ClientConfigurationService = clientConfigurationService;
        }

        [FunctionName("GetSensors")]
        public IActionResult GetSensorsDetails([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
          ILogger log)
        {
            try
            {
                log.LogInformation("GetSensors HTTP trigger function processed a request.");
                var result = ClientConfigurationService.GetSensorsDetails();

                return new OkObjectResult(result);
            }
            catch (Exception ex)
            {
                log.LogError($"GetSenors API failed to process the request with Exception: {ex.StackTrace}");

                return new ObjectResult(new ObjectResult(ex.Message)
                {
                    StatusCode = 500
                });
            }
        }
    }
}
