﻿using Growlink.ClientConfiguration.Models.Models;
using Growlink.ClientConfiguration.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Growlink.ClientConfiguration.Listener
{
    public class AddClientSensors
    {
        private IClientConfigurationService ClientConfigurationService { get; }
        public AddClientSensors(IClientConfigurationService clientConfigurationService)
        {
            ClientConfigurationService = clientConfigurationService;
        }

        [FunctionName("AddClientSensors")]
        public IActionResult AddClientSensorsDetails([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            ConfigurationResponse response = new ConfigurationResponse();
            try
            {
                string requestBody = new StreamReader(req.Body).ReadToEnd();
                List<ClientSensors> clientSensors = JsonConvert.DeserializeObject<List<ClientSensors>>(requestBody);
                response =  ClientConfigurationService.InsertClientSensors(clientSensors);
            }
            catch (Exception ex)
            {
                response.Message = "Unable to cast the JSON body";
                log.LogError($"Add Client Sensors API failed to process the request with Exception: {ex.StackTrace}");
            }

            return new OkObjectResult(response);
        }
    }
}
