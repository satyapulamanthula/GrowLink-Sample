﻿using Growlink.ClientConfiguration.Models.Models;
using Growlink.ClientConfiguration.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System;

namespace Growlink.ClientConfiguration.Listener
{
    public class GetClient
    {
        private IClientConfigurationService ClientConfigurationService { get; }
        public GetClient(IClientConfigurationService clientConfigurationService)
        {
            ClientConfigurationService = clientConfigurationService;
        }

        [FunctionName("GetClient")]
        public IActionResult GetClientDetails([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
           ILogger log)
        {
            try
            {
                log.LogInformation("GetClient HTTP trigger function processed a request.");
                string organizationId = req.Query["clientId"].ToString();
                if (!string.IsNullOrEmpty(organizationId))
                {
                    log.LogInformation($"GetClient request started processing with the clientId: {organizationId}");
                    var result = ClientConfigurationService.GetClient(organizationId);

                    return new OkObjectResult(result);
                }
                else
                {
                    return new BadRequestObjectResult(new ConfigurationResponse { Message = "Invalid Query Parameters" });
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Get Client API failed to process the request with Exception: {ex.StackTrace}");

                return new ObjectResult(new ObjectResult(ex.Message)
                {
                    StatusCode = 500
                });
            }
        }
    }
}
