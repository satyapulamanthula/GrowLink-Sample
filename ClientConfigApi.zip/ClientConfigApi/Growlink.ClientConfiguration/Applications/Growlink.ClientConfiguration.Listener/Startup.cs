﻿using Azure.Data.Tables;
using Growlink.ClientConfiguration.Services.Interfaces;
using Growlink.ClientConfiguration.Services.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using System;

[assembly: FunctionsStartup(typeof(Growlink.ClientConfiguration.Listener.Startup))]
namespace Growlink.ClientConfiguration.Listener
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            string connectionString = Environment.GetEnvironmentVariable("ClientConfigConnection");
            TableServiceClient tableServiceClient = new TableServiceClient(connectionString);
            TableClient tableClient = tableServiceClient.GetTableClient("Clients");
            tableClient.CreateIfNotExists();
            TableClient tableClientSensors = tableServiceClient.GetTableClient("ClientSensors");
            tableClientSensors.CreateIfNotExists();
            // Register services here
            builder.Services.AddSingleton<IClientConfigurationService, ClientConfigurationService>();
        }
    }
}
