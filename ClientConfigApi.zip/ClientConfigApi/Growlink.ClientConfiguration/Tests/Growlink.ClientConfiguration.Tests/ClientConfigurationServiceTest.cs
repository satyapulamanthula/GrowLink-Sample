﻿using Azure.Data.Tables;
using Growlink.ClientConfiguration.Models.Models;
using Growlink.ClientConfiguration.Services.Interfaces;
using Growlink.ClientConfiguration.Services.Services;
using Microsoft.Extensions.Logging;
using NSubstitute;

namespace Growlink.ClientConfiguration.Tests
{
    public class ClientConfigurationServiceTest
    {
        private readonly ILogger<ClientConfigurationService> _logger;
        private readonly TableServiceClient _tableServiceClient;
        private readonly IClientConfigurationService _service;

        public ClientConfigurationServiceTest()
        {
            _logger = Substitute.For<ILogger<ClientConfigurationService>>();
            _tableServiceClient = Substitute.For<TableServiceClient>();
            _service = Substitute.For<IClientConfigurationService>();
        }

        [Fact]
        public void InsertClientConfiguration_ShouldReturnClientCreated_WhenClientNotExist()
        {
            // Arrange
            var clientConfig = new ClientConfig
            {
                ClientId = "27bfbb87-3b8e-4683-87bd-e6d2e1734750",
                APIKey = "test-api-key",
                ClientName = "Test Client"
            };
            _service.InsertClientConfiguration(Arg.Any<ClientConfig>()).Returns(new ConfigurationResponse { Message = "Client created successfully" });

            //Act
            var result = _service.InsertClientConfiguration(clientConfig);

            //Assert
            Assert.NotNull(result);
            Assert.Equal("Client created successfully", result.Message);
        }

        [Fact]
        public void InsertClientConfiguration_ShouldReturnClientCreated_WhenClientExist()
        {
            // Arrange
            var clientConfig = new ClientConfig
            {
                ClientId = "27bfbb87-3b8e-4683-87bd-e6d2e1734750",
                APIKey = "3d81086f-a00e-4191-960e-a5b92a841650",
                ClientName = "Aranet Testing 1"
            };
            _service.InsertClientConfiguration(Arg.Any<ClientConfig>()).Returns(new ConfigurationResponse { Message = "Client already exists" });

            //Act
            var result = _service.InsertClientConfiguration(clientConfig);

            //Assert
            Assert.NotNull(result);
            Assert.Equal("Client already exists", result.Message);
        }

        [Fact]
        public void InsertClientSensors_ShouldInsertSensors_WhenSensorsDataIsValid()
        {
            // Arrange
            var clientSensors = new List<ClientSensors>
            {
                new ClientSensors { BaseStationId = "station1", SensorId = "sensor1", ClientId = "client1" }
            };

            _service.InsertClientSensors(Arg.Any<List<ClientSensors>>()).Returns(new ConfigurationResponse { Message = "Sensors data Added successfully" });


            // Act
            var result = _service.InsertClientSensors(clientSensors);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Sensors data Added successfully", result.Message);
        }


        [Fact]
        public void InsertClientSensors_ShouldReturnNoDataFound_WhenClientSensorsListIsEmpty()
        {
            // Arrange
            var clientSensors = new List<ClientSensors>();
            _service.InsertClientSensors(Arg.Any<List<ClientSensors>>()).Returns(new ConfigurationResponse { Message = "No sensor Data found" });
            // Act
            var result = _service.InsertClientSensors(clientSensors);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("No sensor Data found", result.Message);
        }
    }
}