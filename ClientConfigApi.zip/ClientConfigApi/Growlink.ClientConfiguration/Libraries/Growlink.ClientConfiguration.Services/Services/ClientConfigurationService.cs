﻿using Azure;
using Azure.Data.Tables;
using Growlink.ClientConfiguration.Models.Models;
using Growlink.ClientConfiguration.Repository.Entities;
using Growlink.ClientConfiguration.Services.Interfaces;
using Microsoft.Extensions.Logging;

namespace Growlink.ClientConfiguration.Services.Services
{
    public class ClientConfigurationService : IClientConfigurationService
    {
        private ILogger<ClientConfigurationService> Logger;
        private string ConnectionString { get; } = Environment.GetEnvironmentVariable("ClientConfigConnection");
        public ClientConfigurationService(ILogger<ClientConfigurationService> logger)
        {
            logger.LogInformation("Setting up the connection");
            Logger = logger;
        }
        public virtual ConfigurationResponse InsertClientConfiguration(ClientConfig clientConfig)
        {
            Logger.LogInformation("Started processing client configuration creation request");
            ConfigurationResponse response = new ConfigurationResponse();
            TableServiceClient tableServiceClient = new TableServiceClient(ConnectionString);
            TableClient tableClient = tableServiceClient.GetTableClient("Clients");

            Client client = new Client
            {
                PartitionKey = Environment.GetEnvironmentVariable("PartitionKey"),
                RowKey = clientConfig.ClientId.ToString(),
                APIKey = clientConfig.APIKey,
                ClientName = clientConfig.ClientName
            };
            var clientDetails = GetClient(clientConfig.ClientId.ToString()).Result as ConfigResponse;
            if (clientDetails.ClientConfig != null)
            {
                response.Message = "Client already exists";
                response.Result = clientDetails;
            }
            else
            {
                tableClient.UpsertEntity(client);
                response.Message = "Client created successfully";
                response.Result = client;
            }
            Logger.LogInformation("Successfully added the client detatils");

            return response;
        }

        public ConfigurationResponse GetClient(string clientId)
        {
           
            ConfigResponse configResponse = new ConfigResponse();
            try
            {
                Logger.LogInformation($"Started fetching the client information with clientId:{clientId}");
                TableServiceClient tableServiceClient = new TableServiceClient(ConnectionString);

                TableClient tableClient = tableServiceClient.GetTableClient("Clients");
                TableClient tableClientSensors = tableServiceClient.GetTableClient("ClientSensors");
                Logger.LogInformation($"Table objects created successfully");

                // Fetch the entity based on PartitionKey and RowKey
                var entity = tableClient.Query<Client>(c => c.RowKey == clientId).FirstOrDefault();

                if (entity != null)
                {
                    configResponse.ClientConfig = new ClientConfig
                    {
                        APIKey = entity.APIKey,
                        ClientName = entity.ClientName,
                        ClientId = entity.RowKey,
                    };
                    Pageable<ClientSensor> configSensorsList = tableClientSensors.Query<ClientSensor>(entity => entity.PartitionKey == clientId);
                    
                    foreach (ClientSensor sensors in configSensorsList)
                    {
                        configResponse.ClientSenors.Add(new ClientSensors
                        {
                            BaseStationId = sensors.BaseStationId,
                            ClientId = sensors.PartitionKey,
                            SensorId = sensors.RowKey
                        });
                    }
                }

                return new ConfigurationResponse
                {
                    Result = configResponse
                };
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                Logger.LogError("Client information is not found");
                return new ConfigurationResponse
                {
                    Message = "Client Not Found"
                };
            }
            catch(Exception ex)
            {
                Logger.LogError($"Failed to process the request with an Exception: {ex.StackTrace}");
                return new ConfigurationResponse
                {
                    Message = ex.Message
                };
            }
        }

        public virtual ConfigurationResponse InsertClientSensors(List<ClientSensors> clientSensors)
        {
            Logger.LogInformation("Started inserting sensors information");
            if (!clientSensors.Any()) return new ConfigurationResponse
            {
                Message = "No sensor Data found"
            };
            TableServiceClient tableServiceClient = new TableServiceClient(ConnectionString);
            TableClient tableClient = tableServiceClient.GetTableClient("ClientSensors");
            
            foreach (var clientSensor in clientSensors)
            {
                ConfigResponse client = GetClient(clientSensor.ClientId).Result as ConfigResponse;
                List<ClientSensors> sensorsData = client.ClientSenors;
                ClientSensors sensorData = sensorsData.FirstOrDefault(s => s.BaseStationId == clientSensor.BaseStationId && s.SensorId == clientSensor.SensorId);
                if (sensorData == null && client.ClientConfig != null)
                {
                    var sensors = new ClientSensor
                    {
                        PartitionKey = clientSensor.ClientId,
                        RowKey = clientSensor.SensorId,
                        BaseStationId = clientSensor.BaseStationId
                    };
                    tableClient.AddEntity(sensors);
                }
            }
            Logger.LogInformation("Completed adding sensors information");

            return new ConfigurationResponse
            {
                Message = "Sensors data Added successfully"
            };
        }

        public virtual ConfigurationResponse GetSensorsDetails()
        {
            try
            {
                Logger.LogInformation("Started getting sensors information");
                TableServiceClient tableServiceClient = new TableServiceClient(ConnectionString);
                TableClient tableClient = tableServiceClient.GetTableClient("ClientSensors");
                Pageable<ClientSensor> configSensorsList = tableClient.Query<ClientSensor>();
                List<ClientSensors> clientSensors = new List<ClientSensors>();
                foreach (ClientSensor sensors in configSensorsList)
                {
                    clientSensors.Add(new ClientSensors
                    {
                        BaseStationId = sensors.BaseStationId,
                        ClientId = sensors.PartitionKey,
                        SensorId = sensors.RowKey
                    });
                }

                return new ConfigurationResponse
                {
                    Result = clientSensors
                };

            }
            catch (Exception ex)
            {
                Logger.LogError($"GetSensorsDetails API failed with the Exception: {ex.Message}");
                return new ConfigurationResponse
                {
                    Message = "Unable to process the request"
                };
            }
        }
    }
}
