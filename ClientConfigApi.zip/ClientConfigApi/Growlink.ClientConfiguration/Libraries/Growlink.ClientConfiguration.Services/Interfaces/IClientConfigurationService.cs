﻿using Growlink.ClientConfiguration.Models.Models;

namespace Growlink.ClientConfiguration.Services.Interfaces
{
    public interface IClientConfigurationService
    {
        ConfigurationResponse InsertClientConfiguration(ClientConfig clientConfig);
        ConfigurationResponse GetClient(string orgnizationId);
        ConfigurationResponse InsertClientSensors(List<ClientSensors> clientSensors);
        ConfigurationResponse GetSensorsDetails();
    }
}
