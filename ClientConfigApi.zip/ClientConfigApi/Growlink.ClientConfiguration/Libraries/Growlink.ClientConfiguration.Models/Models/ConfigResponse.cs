﻿using Newtonsoft.Json;

namespace Growlink.ClientConfiguration.Models.Models
{
    public class ConfigResponse
    {
        [JsonProperty("clientConfig")]
        public ClientConfig ClientConfig { get; set; }
        [JsonProperty("clientSensors")]
        public List<ClientSensors> ClientSenors { get; set; } = new List<ClientSensors>();
    }
}
