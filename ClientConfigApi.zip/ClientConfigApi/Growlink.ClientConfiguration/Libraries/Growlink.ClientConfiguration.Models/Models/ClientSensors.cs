﻿using Newtonsoft.Json;

namespace Growlink.ClientConfiguration.Models.Models
{
    public class ClientSensors
    {
        [JsonProperty("clientId")]
        public string ClientId { get; set; }
        [JsonProperty("baseStationId")]
        public string BaseStationId { get; set; }
        [JsonProperty("sensorId")]
        public string SensorId { get; set; }
    }
}
