﻿using Newtonsoft.Json;

namespace Growlink.ClientConfiguration.Models.Models
{
    public class ClientConfig
    {
        [JsonProperty("apiKey")]
        public string APIKey { get; set; }
        [JsonProperty("clientId")]
        public string ClientId { get; set; }
        [JsonProperty("clientName")]
        public string ClientName { get; set; }
    }
}
