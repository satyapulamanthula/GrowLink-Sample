﻿using Newtonsoft.Json;

namespace Growlink.ClientConfiguration.Models.Models
{
    public class ConfigurationResponse
    {
        [JsonProperty("message")]
        public string Message { get; set; }
        [JsonProperty("result")]
        public object Result { get; set; }
    }
}
