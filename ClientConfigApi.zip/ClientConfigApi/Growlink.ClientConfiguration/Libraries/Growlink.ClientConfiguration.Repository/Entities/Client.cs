﻿using Azure;
using Azure.Data.Tables;

namespace Growlink.ClientConfiguration.Repository.Entities
{
    public class Client : ITableEntity
    {
        // Required Properties
        public string PartitionKey { get; set; }
        /// <summary>
        /// The RowKey will be used to store Client Id
        /// </summary>
        public string RowKey { get; set; }
        DateTimeOffset? ITableEntity.Timestamp { get; set; } = DateTime.UtcNow;
        ETag ITableEntity.ETag { get; set; }

        //Custom Properties
        public string APIKey { get; set; }
        public string ClientName { get; set; }
    }
}
