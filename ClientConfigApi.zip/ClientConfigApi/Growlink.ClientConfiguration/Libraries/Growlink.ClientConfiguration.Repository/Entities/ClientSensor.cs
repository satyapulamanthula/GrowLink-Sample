﻿using Azure;
using Azure.Data.Tables;

namespace Growlink.ClientConfiguration.Repository.Entities
{
    public class ClientSensor : ITableEntity
    {
        //Default properties
        /// <summary>
        /// The PartitionKey will be used to store Client Id
        /// </summary>
        public string PartitionKey { get; set; }
        /// <summary>
        /// The RowKey will be used to store Sensor Id
        /// </summary>
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        //custom properties
        public string BaseStationId { get; set; }
    }
}
