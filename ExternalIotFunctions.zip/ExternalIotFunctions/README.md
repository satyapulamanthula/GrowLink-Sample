# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)

#Debugging Process for Schema conversion Http Function
1.	Here we are using Ngrok third part tool to help in debugging.
2.	Download the ngrok file from the following link: Download (ngrok.com) 
 
3.	Selecting for the respective operating system and version and click on the download button.
4.	Create an account in the ngrok website.
5.	Run the ‘Growlink.SensorSchemaConversion.Listener’ function in the Visual studio.
6.	Command prompt with the local host connected port will open. Copy the port number, here it is 7424
 
7.	Run the downloaded Ngrok.exe file.
8.	Ngrok command prompt will open as shown below
 
9.	Now we need authentication token from Ngrok, open the ngrok website with your account and navigate to the ‘Your Authtoken’ page from side menu.
10.	Then copy the authentication token.
 
11.	Run the below command in the ngrok command prompt
ngrok config add-authtoken $YOUR_AUTHTOKEN

Replace $YOUR_AUTHTOKEN with the authtoken copied from Ngrok authtoken page.
12.	Now again run the following command in ngrok command prompt: 
ngrok http $port number
Replace $port number with port number copied initially from local host command prompt.
 
13.	Then you will get a forwarding api in the command prompt.
 
14.	Copy the highlighted ‘forwarding’ api.
15.	Open the previously opened visual studio command prompt and copy the ‘SensorDataListener’ API and replace the initial local host base api till portnumber with the ‘Forwarding’ API from ngrok to form a final Url to use in Aranet
Example :
Sensor Data listener API: http://localhost:7274/api/SensorDataListener
Fowarding API: https://acd8-182-72-175-14.ngrok-free.app
URL: https://acd8-182-72-175-14.ngrok-free.app/api/SensorDataListener
 
16.	Now open ‘Aranet Cloud’ and navigate to the ‘API Integration’ Page and click on ‘edit button’ of your created API integration.
 
17.	Now in the URL field provide the URL built in step 15 and save the integration and enable it.
 
18.	Now the data from the Aranet is displayed while debugging the code.
