using Growlink.SensorSchemaConversion.Models.Models;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Growlink.SensorSchemaConversion.Listener
{
    /// <summary>
    /// The SensorDataListener will listen the sensor data from the aranet cloud and transfromed into the standard format
    /// </summary>
    public class SensorDataListener
    {
        private ISensorSchemaConversionService SensorSchemaConversionService;
        private readonly IClientConfigService ClientConfigService;

        public SensorDataListener(ISensorSchemaConversionService sensorSchemaConversionService, IClientConfigService clientConfigService)
        {
            SensorSchemaConversionService = sensorSchemaConversionService;
            ClientConfigService = clientConfigService;
        }

        [FunctionName("SensorDataListener")]
        public IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation($"SensorDataListener started processing request at {DateTime.UtcNow}");
            dynamic result = null;
            try
            {

                string clientId = string.Empty;
              
                if (req.Headers.ContainsKey("ClientId"))
                {
                    clientId += $"{req.Headers["ClientId"]}";
                }

                ConfigResponse clientResponse = ClientConfigService.GetClientDetails(clientId);
                
                if (string.IsNullOrEmpty(clientResponse.Message))
                {
                    string requestBody = new StreamReader(req.Body).ReadToEnd();
                    List<SensorData> sensorsData = JsonConvert.DeserializeObject<List<SensorData>>(requestBody);
                    log.LogInformation($"SensorDataListener : The Sensor Data Request Body \n {(requestBody)}");

                    result = SensorSchemaConversionService.ProcessSensorData(clientResponse, sensorsData, clientId);
                    log.LogInformation($"SensorDataListener : The Sensor Data response  \n {(JsonConvert.SerializeObject(result))}");

                }
                else
                {
                    log.LogInformation("No data with given clientId");
                    return new ObjectResult(new ObjectResult("No data found with the given clientId")
                    {
                        StatusCode = 500
                    });
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Failed to process the request with Exception: {ex.StackTrace}");
            }

            return new OkObjectResult(result);
        }
    }
}
