using Azure.Messaging.EventHubs;
using Growlink.SensorSchemaConversion.Common.Helpers;
using Growlink.SensorSchemaConversion.Models.Models;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Listener
{
    public class IoTHubTrigger
    {

        private ISensorSchemaConversionService SensorSchemaConversionService;
        private IClientConfigService ClientConfigService;

        public IoTHubTrigger(ISensorSchemaConversionService sensorSchemaConversionService, 
            IClientConfigService clientConfigService)
        {
            SensorSchemaConversionService = sensorSchemaConversionService;
            ClientConfigService = clientConfigService;
        }
        [FunctionName("AzureHubTrigger")]
        public async Task Run([EventHubTrigger("%IoTHubName%", Connection = "IoTHubConnection")] EventData[] events, ILogger log)
        {
            try
            {
                List<ClientSensors> clientSensors = ClientConfigService.GetAllClientSensors();

                foreach (EventData eventData in events)
                {
                    var jsonString = eventData.EventBody.ToString();

                    log.LogInformation($"C# Event Hub trigger function processed a message: {jsonString}");
                    log.LogInformation($"Stored JSON data form the iot Hub: {jsonString}");
                    var sensorsData = JsonConvert.DeserializeObject<HubSensorList>(jsonString);

                    var convertedSensorList = SensorSchemaConversionService.SensorDataObjectBuilder(sensorsData);
                    var translationResult = SensorSchemaConversionService.TranslateSensorData(new Sensors(), convertedSensorList, clientSensors, true);
                    log.LogInformation($"The sensor data has been converted as below\n {JsonConvert.SerializeObject(translationResult)}");
                    EventHubHelper.SendMessageToEventHub(JsonConvert.SerializeObject(translationResult));
                    log.LogInformation("Successfully published data into Azure Event Hub");
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Failed to process the request with Exception: {ex.StackTrace}");
            }
        }
    }
}
