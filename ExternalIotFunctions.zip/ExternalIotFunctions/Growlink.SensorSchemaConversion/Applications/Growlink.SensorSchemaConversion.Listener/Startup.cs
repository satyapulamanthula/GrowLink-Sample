﻿using Growlink.SensorSchemaConversion.Services.Interfaces;
using Growlink.SensorSchemaConversion.Services.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(Growlink.SensorSchemaConversion.Listener.Startup))]
namespace Growlink.SensorSchemaConversion.Listener
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            // Register services here
            builder.Services.AddSingleton<ISensorSchemaConversionService, SensorSchemaConversionService>();
            builder.Services.AddSingleton<IClientConfigService, ClientConfigService>();
            builder.Services.AddSingleton<IBaseDataService, BaseDataService>();
        }
    }
}
