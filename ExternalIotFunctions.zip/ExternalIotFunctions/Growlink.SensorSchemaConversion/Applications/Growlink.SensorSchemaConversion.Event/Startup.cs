﻿using Growlink.SensorSchemaConversion.Services.Interfaces;
using Growlink.SensorSchemaConversion.Services.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: FunctionsStartup(typeof(Growlink.SensorSchemaConversion.Event.Startup))]
namespace Growlink.SensorSchemaConversion.Event
{
    public class Startup: FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            // Register services here
            builder.Services.AddSingleton<ISensorSchemaConversionService, SensorSchemaConversionService>();
        }
    }
}
