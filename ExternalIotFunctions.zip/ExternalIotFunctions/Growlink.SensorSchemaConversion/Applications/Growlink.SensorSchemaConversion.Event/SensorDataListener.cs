// Default URL for triggering event grid function in the local environment.
// http://localhost:7071/runtime/webhooks/EventGrid?functionName={functionname}
using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.EventGrid;
using Microsoft.Extensions.Logging;
using Azure.Messaging.EventGrid;
using Azure.Messaging.EventHubs;
using Newtonsoft.Json;
using Growlink.SensorSchemaConversion.Models.Models;
using System.Collections.Generic;
using Growlink.SensorSchemaConversion.Services.Services;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Growlink.SensorSchemaConversion.Common.Helpers;

namespace Growlink.SensorSchemaConversion.Event
{
    public class SensorDataListener
    {
        private ISensorSchemaConversionService SensorSchemaConversionService;

        public SensorDataListener(ISensorSchemaConversionService sensorSchemaConversionService)
        {
            SensorSchemaConversionService = sensorSchemaConversionService;
        }
        [FunctionName("SensorDataEventGridListener")]
        public void Run([EventGridTrigger] EventGridEvent eventGridEvent, ILogger log)
        {
            try
            {
                log.LogInformation("Event Listener  started");
                var requestString = eventGridEvent.Data.ToString();
                log.LogInformation($"Request recieved form the MQTT Broker: {requestString}");
                var deserializedData = JsonConvert.DeserializeObject<List<SensorData>>(requestString);
                log.LogInformation($"Request is Deserailized: {deserializedData}");
                var result = SensorSchemaConversionService.TranslateSensorData(new Sensors(), deserializedData, true);
                log.LogInformation("Sensor data is translated");
                EventHubHelper.SendMessageToEventHub(JsonConvert.SerializeObject(result));
                log.LogInformation("Successfully published data into Azure Event Hub");
            
            }
            catch (Exception ex)
            {
                log.LogError($"Failed to process the request with Exception: {ex.StackTrace}");
            }

        }
    }
}
