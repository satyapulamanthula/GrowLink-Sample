﻿using Growlink.SensorSchemaConversion.Common.Attributes;
using System.Reflection;

namespace Growlink.SensorSchemaConversion.Common.Helpers
{
    public class EnumHelper
    {
        public static TEnum GetEnumByMappings<TEnum>(string alias, TEnum defaultValue) where TEnum : Enum
        {
            try
            {
                var enumType = typeof(TEnum);
                foreach (var field in enumType.GetFields(BindingFlags.Public | BindingFlags.Static))
                {
                    var aliasAttribute = field.GetCustomAttribute<EnumMappingAttribute>();

                    if (aliasAttribute != null && aliasAttribute.Mappings.Contains(alias, StringComparer.OrdinalIgnoreCase))
                    {
                        return (TEnum)field.GetValue(null);
                    }
                }
            }
            catch (Exception) 
            {
                return defaultValue;
            }
           
            return defaultValue;
        }
    }
}
