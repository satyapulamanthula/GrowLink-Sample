﻿using Growlink.SensorSchemaConversion.Models.Models;
using Microsoft.Extensions.Logging;

namespace Growlink.SensorSchemaConversion.Common.Helpers
{
    public class DataGroupingHelper
    {
        public static List<List<SensorData>> GroupSensorData(List<SensorData> sensorData, ILogger logger)
        {
            List<List<SensorData>> groupedSensorData = new List<List<SensorData>>();
            try
            {
                logger.LogInformation("Grouping the sensor data");
                List<SensorData> currentSensorGroup = new List<SensorData>();
                foreach (SensorData sensor in sensorData)
                {
                    // If an item has the "BaseTime" value, it's the start of a new group
                    if (sensor.BaseTime != null)
                    {
                        // If the current group is not empty, add it to the groupedData
                        if (currentSensorGroup.Count > 0)
                        {
                            groupedSensorData.Add(currentSensorGroup);
                        }

                        // Start a new group with the current item
                        currentSensorGroup = new List<SensorData> { sensor };
                    }
                    else
                    {
                        // If "BaseTime" is missing, add the item to the current group
                        currentSensorGroup.Add(sensor);
                    }
                }
                // Add the last group to the list if it's not empty
                if (currentSensorGroup.Count > 0)
                {
                    groupedSensorData.Add(currentSensorGroup);
                }
            }
            catch (Exception ex) 
            {
                logger.LogError($"Failed to grouping the sensor data with Exception: {ex.StackTrace}");
            }
            
            return groupedSensorData;
        }
    }
}
