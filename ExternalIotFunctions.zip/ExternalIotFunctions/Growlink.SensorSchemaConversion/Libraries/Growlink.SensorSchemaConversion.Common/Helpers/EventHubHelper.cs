﻿using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Common.Helpers
{
    public class EventHubHelper
    {
        public static async Task SendMessageToEventHub(string jsonData)
        {
            try
            {
                string connectionString = Environment.GetEnvironmentVariable("EventHubConnection");
                string eventHubName = Environment.GetEnvironmentVariable("EventHubName");
                await using (var producerClient = new EventHubProducerClient(connectionString, eventHubName))
                {
                    using EventDataBatch eventBatch = await producerClient.CreateBatchAsync();

                    eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes(jsonData)));

                    await producerClient.SendAsync(eventBatch);
                }
            }
            catch(Exception ex)
            {
                throw;
            }
            
        }
    }
}
