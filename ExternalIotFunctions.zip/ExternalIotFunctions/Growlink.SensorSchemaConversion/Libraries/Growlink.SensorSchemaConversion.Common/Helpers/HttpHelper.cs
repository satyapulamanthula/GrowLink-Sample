﻿using Growlink.SensorSchemaConversion.Models.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Common.Helpers
{
    public class HttpHelper<T> where T:class
    {
        public static T Get<T>(string baseUrl, string api, string queryParams, AuthenticationHeaderValue headers = null)
        {
            using (HttpClient client = new HttpClient())
            {
                string url = $"{baseUrl}/{api}";
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Authorization = headers;
                HttpResponseMessage response = client.GetAsync(queryParams).Result;
                response.EnsureSuccessStatusCode();
                string resultString = response.Content.ReadAsStringAsync().Result;
                T result = JsonConvert.DeserializeObject<T>(resultString);

                return result;
            }
        }

        public static bool Post<T>(string baseUrl, string api, T request, AuthenticationHeaderValue headers = null)
        {
            using (HttpClient client = new HttpClient())
            {
                string url = $"{baseUrl}/{api}";
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Authorization = headers;
                string serializedObject = JsonConvert.SerializeObject(request);
                var content = new StringContent(serializedObject, Encoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync(url, content).Result;
            }
                return true;
        }
    }
}
