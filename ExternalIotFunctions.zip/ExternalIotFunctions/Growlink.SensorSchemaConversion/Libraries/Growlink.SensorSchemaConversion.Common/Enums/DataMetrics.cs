﻿using Growlink.SensorSchemaConversion.Common.Attributes;

namespace Growlink.SensorSchemaConversion.Common.Enums
{
    public enum DataMetrics
    {
        [EnumMapping("None")]
        None = 255,
        [EnumMapping("Temperature")]
        Temperature = 0,
        [EnumMapping("Humidity")]
        Humidity = 1,
        [EnumMapping("Acidity")]
        Acidity = 2,
        [EnumMapping("CarbonDioxideLevel")]
        CarbonDioxideLevel = 3,
        [EnumMapping("TotalDissolvedSolids")]
        TotalDissolvedSolids = 4,
        [EnumMapping("FloatLevel")]
        FloatLevel = 5,
        [EnumMapping("LightLevel")]
        LightLevel = 6,
        [EnumMapping("BatteryLevel")]
        BatteryLevel = 7,
        [EnumMapping("VaporPressureDeficit")]
        VaporPressureDeficit = 8,
        [EnumMapping("WaterContent")]
        WaterContent = 9,
        [EnumMapping("ElectricalConductivity")]
        ElectricalConductivity = 10,
        [EnumMapping("Voltage")]
        Voltage = 11,
        [EnumMapping("ElectricCurrent")]
        ElectricCurrent = 12,
        [EnumMapping("SwitchState")]
        SwitchState = 15,
        [EnumMapping("DissolvedOxygen")]
        DissolvedOxygen = 13,
        [EnumMapping("FlowRate")]
        FlowRate = 14,
        [EnumMapping("VaporPressure")]
        VaporPressure = 16,
        [EnumMapping("AtmosphericPressure")]
        AtmosphericPressure = 17,
        [EnumMapping("WindDirection")]
        WindDirection = 18,
        [EnumMapping("WindSpeed")]
        WindSpeed = 19,
        [EnumMapping("Par")]
        Par = 20,
        [EnumMapping("Precipitation")]
        Precipitation = 21,
        [EnumMapping("DailyLightIntegral")]
        DailyLightIntegral = 22,
        [EnumMapping("ElectricalResistance")]
        ElectricalResistance = 23,
        [EnumMapping("ReactiveOxygenSpecies")]
        ReactiveOxygenSpecies = 24,
        [EnumMapping("ColorTemperature")]
        ColorTemperature = 25,
        [EnumMapping("LightFlicker")]
        LightFlicker = 26,
        [EnumMapping("WaterPressure")]
        WaterPressure = 27,
        [EnumMapping("OxidationReductionPotential")]
        OxidationReductionPotential = 28,
        [EnumMapping("TankLevel")]
        TankLevel = 29,
        [EnumMapping("TankVolume")]
        TankVolume = 30
    }
}
