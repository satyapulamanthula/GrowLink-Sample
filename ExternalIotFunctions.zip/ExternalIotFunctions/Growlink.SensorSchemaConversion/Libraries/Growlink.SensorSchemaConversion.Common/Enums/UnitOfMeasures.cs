﻿using Growlink.SensorSchemaConversion.Common.Attributes;

namespace Growlink.SensorSchemaConversion.Common.Enums
{
    public enum UnitOfMeasures
    {
        [EnumMapping("None")]
        None = 255,
        [EnumMapping("cel", "°C")]
        Celsius = 0,
        [EnumMapping("°F")]
        Fahrenheit = 1,
        [EnumMapping("None")]
        pH = 2,
        [EnumMapping("ppm")]
        PartsPerMillion = 3,
        [EnumMapping("ppb")]
        PartsPerBillion = 31,
        [EnumMapping("%", "%RH")]
        Percentage = 4,
        [EnumMapping("None")]
        HighLow = 5,
        [EnumMapping("S/m")]
        EC = 6,
        [EnumMapping("lx")]
        Lux = 7,
        [EnumMapping("kPa")]
        kPa = 8,
        [EnumMapping("mbar")]
        Millibars = 9,
        [EnumMapping("V")]
        Volts = 10,
        [EnumMapping("A")]
        Amperes = 11,
        [EnumMapping("None")]
        OnOff = 12,
        [EnumMapping("GPM")]
        GallonsPerMinute = 13,
        [EnumMapping("°", "deg")]
        Angle = 14,
        [EnumMapping("m/s")]
        MetersPerSecond = 15,
        [EnumMapping("µmol/m²/s")]
        PPFD = 16,
        [EnumMapping("None")]
        PPFD_NaturalDaylight6500K = 20,
        [EnumMapping("None")]
        PPFD_HalogenLamp3000K = 21,
        [EnumMapping("None")]
        PPFD_HighCriLed6500K = 22,
        [EnumMapping("None")]
        PPFD_HighCriLed4000K = 23,
        [EnumMapping("None")]
        PPFD_HighCriLed3000K = 24,
        [EnumMapping("None")]
        PPFD_LowCriLed6500K = 25,
        [EnumMapping("None")]
        PPFD_LowCriLed3500K = 26,
        [EnumMapping("None")]
        PPFD_Hps2000K = 27,
        [EnumMapping("None")]
        PPFD_Cmh3000K = 28,
        [EnumMapping("mm/h")]
        MillimetersPerHour = 17,
        [EnumMapping("mA")]
        Milliamps = 18,
        [EnumMapping("wc")]
        InchesOfWater = 19,
        [EnumMapping("µmol/m²/d", "mol/m2/s")]
        MolesPerSquareMeterPerDay = 29,
        [EnumMapping("Ω")]
        Ohms = 30,
        [EnumMapping("dS/m")]
        DeciSiemensPerMeter = 32,
        [EnumMapping("µS/m")]
        MicroSiemensPerCentimeter = 33,
        [EnumMapping("W/m 2")]
        WattsPerSquareMeter = 34,
        [EnumMapping("K")]
        DegreesKelvin = 35,
        [EnumMapping("Hz")]
        Hertz = 36,
        [EnumMapping("mV")]
        MilliVolts = 37,
        [EnumMapping("psi")]
        PoundsPerSquareInch = 38,
        [EnumMapping("bar")]
        Bars = 39,
        [EnumMapping("L/min")]
        LitersPerMinute = 40,
        [EnumMapping("m3/min")]
        CubicMetersPerMinute = 41,
        [EnumMapping("gal")]
        Gallons = 42,
        [EnumMapping("L")]
        Liters = 43,
        [EnumMapping("gal/hr")]
        GallonsPerHour = 44,
        [EnumMapping("L/hr")]
        LitersPerHour = 45,
        [EnumMapping("in")]
        Inches = 46,
        [EnumMapping("m")]
        Meters = 47,
        [EnumMapping("mph")]
        MilesPerHour = 48,
        [EnumMapping("km/h")]
        KilometersPerHour = 49,
        [EnumMapping("mg/L")]
        MilligramsPerLiter = 50
    }
}
