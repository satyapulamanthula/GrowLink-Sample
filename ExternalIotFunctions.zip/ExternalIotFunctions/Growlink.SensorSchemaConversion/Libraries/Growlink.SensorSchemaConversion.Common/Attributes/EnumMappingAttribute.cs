﻿namespace Growlink.SensorSchemaConversion.Common.Attributes
{
    public class EnumMappingAttribute : Attribute
    {
        public string[] Mappings { get; }
        public EnumMappingAttribute(params string[] mappings)
        {
            Mappings = mappings;
        }
    }
}
