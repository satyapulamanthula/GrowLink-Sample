﻿using Growlink.SensorSchemaConversion.Common.Helpers;
using Growlink.SensorSchemaConversion.Models.Models;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;

namespace Growlink.SensorSchemaConversion.Services.Services
{
    public class BaseDataService : IBaseDataService
    {
        private readonly ILogger<BaseDataService> Logger;
        public BaseDataService(ILogger<BaseDataService> logger)
        {
            Logger = logger;
        }

        public BaseDatalList GetBaseData(string apiKey)
        {
            try
            {
                BaseDatalList result = HttpHelper<BaseDatalList>.Get<BaseDatalList>(
                                            Environment.GetEnvironmentVariable("BaseUrl"),
                                            "bases",
                                            "",
                                            new AuthenticationHeaderValue("ApiKey", apiKey));
                return result;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Failed to get the base data with the Exception: {ex.StackTrace}");
                return new BaseDatalList();
            }
        }

        public Sensors GetBaseSensors(string apiKey)
        {
            try
            {
                BaseDatalList baseResponse = GetBaseData(apiKey);
                List<string> baseIds = baseResponse.Bases.Select(s => s.Id).ToList();
                Sensors result = HttpHelper<Sensors>.Get<Sensors>(Environment.GetEnvironmentVariable("BaseUrl"), "sensors", $"?base={string.Join("%2C", baseIds)}", new AuthenticationHeaderValue("ApiKey", apiKey));
                return result;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Failed to get the base sensors data with the Exception: {ex.StackTrace}");
                return new Sensors();
            }
        }
    }

}
