﻿using Growlink.SensorSchemaConversion.Common.Enums;
using Growlink.SensorSchemaConversion.Common.Helpers;
using Growlink.SensorSchemaConversion.Models.Models;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace Growlink.SensorSchemaConversion.Services.Services
{
    public class SensorSchemaConversionService : ISensorSchemaConversionService
    {
        private readonly ILogger<SensorSchemaConversionService> Logger;
        private readonly IBaseDataService BaseDataService;
        private readonly IClientConfigService ClientConfigService;
        public SensorSchemaConversionService(ILogger<SensorSchemaConversionService> logger, 
            IBaseDataService baseDataService,
            IClientConfigService clientConfigService)
        {
            Logger = logger;
            BaseDataService = baseDataService;
            ClientConfigService = clientConfigService;
        }

        public List<dynamic> TranslateSensorData(Sensors baseStations, List<SensorData> sensorsData, List<ClientSensors> clientSensors = null, bool ignoreBase = false)
        {
            Logger.LogInformation($"SensorDataListener : Started Translating the sesnorData at {DateTime.Now}");
            List<dynamic> resultList = new();

            try
            {
                string baseName = default;
                List<List<SensorData>> sensorGroupedData = DataGroupingHelper.GroupSensorData(sensorsData, Logger);
                foreach (var sensorData in sensorGroupedData)
                {
                    Dictionary<string, object> responseDictionary = new Dictionary<string, object>();

                    if (!string.IsNullOrEmpty(sensorData.FirstOrDefault().BaseName))
                    {
                        baseName = sensorData.FirstOrDefault()?.BaseName;
                    }
                    var matchedSensor = baseStations.SensorDetails.Where(s => s.SensorId == baseName).ToList();
                    if (ignoreBase || baseStations.SensorDetails.Where(s => s.SensorId == baseName).Any())
                    {
                        DateTime baseTime = default;
                        if (sensorData.Any(s => s.Name == "time"))
                        {
                            baseTime = DateTimeOffset.FromUnixTimeSeconds(Convert.ToInt64(sensorData.FirstOrDefault(s => s.Name == "time").Value)).DateTime;
                        }
                        else
                        {
                            baseTime = sensorData.FirstOrDefault()?.BaseTime.HasValue == true
                            ? DateTimeOffset.FromUnixTimeSeconds(sensorData.FirstOrDefault().BaseTime.Value).DateTime
                            : DateTime.MinValue;
                        }

                        responseDictionary.Add($"ts", baseTime.ToString("yyyy-MM-dd HH:mm:ss"));
                        if(!ignoreBase)
                        {
                            responseDictionary.Add($"id", matchedSensor.FirstOrDefault().Bases.FirstOrDefault());
                        }
                        else
                        {
                            string baseStationId = clientSensors.FirstOrDefault(s => s.Sensors == baseName)?.BaseStationId ?? string.Empty;
                            responseDictionary.Add($"id", baseStationId);
                        }
                    }

                    responseDictionary.Add($"sn", baseName);
                    int valueIndex = 0;
                    foreach (SensorData sensor in sensorData.Where(s => s.Name != "time"))
                    {
                        valueIndex++;
                        responseDictionary.Add($"a{valueIndex}", sensor.Value);
                        responseDictionary.Add($"am{valueIndex}", (int)EnumHelper.GetEnumByMappings<DataMetrics>(sensor.Name, DataMetrics.None));
                        responseDictionary.Add($"au{valueIndex}", (int)EnumHelper.GetEnumByMappings<UnitOfMeasures>(sensor.Unit, UnitOfMeasures.None));
                    }
                    string convertedResponse = JsonConvert.SerializeObject(responseDictionary, Formatting.Indented);
                    dynamic convertedJsonObject = JsonConvert.DeserializeObject(convertedResponse);
                    resultList.Add(convertedJsonObject);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"SensorDataListener : sensor data Conversion failed with the Exception: {ex.StackTrace}");
                throw;
            }
            return resultList;
        }



        public List<ClientSensors> BuildSensorObject(Sensors baseSationSensors, string clientId, 
            List<SensorData> sensorData, List<ClientSensors> avaliableSensorsData)
        {
            var resultList = new List<ClientSensors>();
            try
            {
                var clientSpecificSensors = avaliableSensorsData.Where(s => s.OrganizationId == clientId).ToList();
                var regex = new Regex(@"aranet:([a-zA-Z0-9]+):");
                sensorData.Where(item => item.BaseName != null).ToList().ForEach(data =>
                {
                    var match = regex.Match(data.BaseName);
                    if (match.Success)
                    {
                        string value = match.Groups[1].Value;
                        data.BaseName =  value.Length > 1 ? value.Substring(1) : null;
                    }
                });

                foreach (var data in sensorData.Where(s => !string.IsNullOrEmpty(s.BaseName)))
                {
                    if (!clientSpecificSensors.Any(s => s.Sensors == data.BaseName))
                    {
                        var sensor = baseSationSensors.SensorDetails.Where(s => s.SensorId == data.BaseName).ToList();
                        if (sensor.Any())
                        {
                            resultList.Add(new ClientSensors
                            {
                                OrganizationId = clientId,
                                BaseStationId = sensor.FirstOrDefault().Bases.FirstOrDefault(),
                                Sensors = data.BaseName
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"client sensor object creation failed with the Exception: {ex.StackTrace}");
                throw;
            }

            return resultList;
        }


        public List<SensorData> SensorDataObjectBuilder(HubSensorList sensorsData)
        {
            var allMySensors = new List<SensorData>();
            foreach (var sensor in sensorsData.Sensors)
            {
                foreach (var measurement in sensor.Measurements)
                {
                    var mySensor = ConvertToMySensor(measurement, sensor.Uid);
                    allMySensors.Add(mySensor);
                }
            }

            return allMySensors;

        }


        public static SensorData ConvertToMySensor(Measurements measurement, string uid)
        {
            return new SensorData
            {
                BaseName = uid.Length > 1 ? uid.Substring(1): string.Empty,
                Name = measurement.Name,
                Value = measurement.Value,
                Unit = measurement.Unit
            };
        }

        public dynamic ProcessSensorData(ConfigResponse clientResponse, List<SensorData> sensorsData, string clientId)
        {
            dynamic result = null;
            ClientConfigResponse clientConfigResponse = JsonConvert.DeserializeObject<ClientConfigResponse>(clientResponse.Result.ToString());
            
            Sensors sensors = BaseDataService.GetBaseSensors(clientConfigResponse.ClientConfig.APIKey);
            List<ClientSensors> avaliableSensorsData = ClientConfigService.GetAllClientSensors();
            List<ClientSensors> clientSensorData = BuildSensorObject(sensors, clientId, sensorsData, avaliableSensorsData);
            var response = ClientConfigService.AddClientSensors(clientSensorData);
            if (!response)
                Logger.LogError("Failed to add the client sensor information");
            
            result = TranslateSensorData(sensors, sensorsData);
            Logger.LogInformation($"SensorDataListener: The sensor data has been converted as below\n {JsonConvert.SerializeObject(result)}");
            EventHubHelper.SendMessageToEventHub(JsonConvert.SerializeObject(result));
            Logger.LogInformation("SensorDataListener : Successfully published data into Azure Event Hub");
            return result;
        }
    }
}
