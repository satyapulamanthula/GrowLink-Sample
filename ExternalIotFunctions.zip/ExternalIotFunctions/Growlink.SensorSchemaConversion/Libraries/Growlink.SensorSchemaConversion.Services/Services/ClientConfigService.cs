﻿using Growlink.SensorSchemaConversion.Common.Helpers;
using Growlink.SensorSchemaConversion.Models.Models;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Services.Services
{
    public class ClientConfigService : IClientConfigService
    {
        private readonly ILogger<ClientConfigService> Logger;
        public ClientConfigService(ILogger<ClientConfigService> logger)
        {
            Logger = logger;
        }

        public bool AddClientSensors(List<ClientSensors> clientSensors)
        {
            try
            {
                if (!clientSensors.Any()) return true;
                var result = HttpHelper<List<ClientSensors>>.Post<List<ClientSensors>>(Environment.GetEnvironmentVariable("ConfigBaseUrl"), "AddClientSensors", clientSensors);
                return result;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Add client sensors method failed to process the request with an Exception: {ex.StackTrace}");
                return false;
            }
        }

        public List<ClientSensors> GetAllClientSensors()
        {
            try
            {
                Logger.LogInformation("Started processing the All client sensor information");
                var clientSensorsResult = HttpHelper<ConfigResponse>.Get<ConfigResponse>(Environment.GetEnvironmentVariable("ConfigBaseUrl"), "GetSensors", "");
                List<ClientSensors> clientSensors = JsonConvert.DeserializeObject<List<ClientSensors>>(clientSensorsResult.Result.ToString());
                return clientSensors;
            }
            catch (Exception ex) 
            {
                Logger.LogError($"Get All client sensors method failed to process the request with an Exception: {ex.StackTrace}");
                return new List<ClientSensors>();
            }
        }

        public ConfigResponse GetClientDetails(string clientId)
        {
            try
            {
                Logger.LogInformation("Started processing the clients information");
                ConfigResponse clientResponse = HttpHelper<ConfigResponse>.Get<ConfigResponse>(Environment.GetEnvironmentVariable("ConfigBaseUrl"), "GetClient", $"?clientId={clientId}");
                return clientResponse;
            }
            catch (Exception ex) 
            {
                Logger.LogError($"Get client information method failed to process the request with an Exception: {ex.StackTrace}");
                return new ConfigResponse();
            }
        }
    }
}
