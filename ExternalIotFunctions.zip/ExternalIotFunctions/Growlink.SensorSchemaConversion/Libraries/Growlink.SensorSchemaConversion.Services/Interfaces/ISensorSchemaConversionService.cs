﻿using Growlink.SensorSchemaConversion.Models.Models;

namespace Growlink.SensorSchemaConversion.Services.Interfaces
{
    public interface ISensorSchemaConversionService
    {
        List<dynamic> TranslateSensorData(Sensors baseStations, List<SensorData> sensorsData, List<ClientSensors> clientSensors = null, bool ignoreBase = false);
        List<ClientSensors> BuildSensorObject(Sensors baseSationSensors, string clientId, List<SensorData> sensorData, List<ClientSensors> avaliableSensorsData);
        List<SensorData> SensorDataObjectBuilder(HubSensorList sensorsData);
        dynamic ProcessSensorData(ConfigResponse clientResponse, List<SensorData> sensorsData, string clientId);
    }
}
