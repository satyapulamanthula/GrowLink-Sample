﻿using Growlink.SensorSchemaConversion.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Services.Interfaces
{
    public interface IClientConfigService
    {
        List<ClientSensors> GetAllClientSensors();
        ConfigResponse GetClientDetails(string clientId);
        bool AddClientSensors(List<ClientSensors> clientSensors);
    }
}
