﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class ClientConfigResponse
    {
        
            [JsonProperty("clientConfig")]
            public ClientConfig ClientConfig { get; set; }
            [JsonProperty("clientSensors")]
            public List<ClientSensors> ClientSenors { get; set; } = new List<ClientSensors>();
        
    }
}
