﻿using Newtonsoft.Json;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class SensorData
    {
        [JsonProperty("bn")]
        public string BaseName { get; set; }
        [JsonProperty("bt")]
        public long? BaseTime { get; set; }
        [JsonProperty("bu")]
        public string BaseUnit { get; set; }
        [JsonProperty("bv")]
        public double BaseValue { get; set; }
        [JsonProperty("bs")]
        public double BaseSum { get; set; }
        [JsonProperty("bver")]
        public int BaseVersion { get; set; }
        [JsonProperty("n")]
        public string Name { get; set; }
        [JsonProperty("u")]
        public string Unit { get; set; }
        [JsonProperty("v")]
        public decimal Value { get; set; }
        [JsonProperty("vs")]
        public string StringValue { get; set; }
        [JsonProperty("vb")]
        public bool BooleanValue { get; set; }
        [JsonProperty("vd")]
        public string DataValue { get; set; }
        [JsonProperty("s")]
        public double Sum { get; set; }
        [JsonProperty("t")]
        public double Time { get; set; }
        [JsonProperty("ut")]
        public double UpdateTime { get; set; }
    }
}
