﻿using Newtonsoft.Json;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class BaseData
    {
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("regdate")]
        public DateTime Regdate { get; set; }
        [JsonProperty("firmware")]
        public string Firmware { get; set; }
        [JsonProperty("product")]
        public string Product { get; set; }
        [JsonProperty("board")]
        public string Board { get; set; }
        [JsonProperty("region")]
        public string Region { get; set; }
        [JsonProperty("self")]
        public string Self { get; set; }
        [JsonProperty("sensors")]
        public string Sensors { get; set; }
        
    }
    public class BaseDatalList
    {
        public List<BaseData> Bases { get; set; } = new List<BaseData>();
    }
}
