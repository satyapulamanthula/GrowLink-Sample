﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class ConfigResponse
    {
        [JsonProperty("message")]
        public string Message { get; set; }
        [JsonProperty("result")]
        public object Result { get; set; }
    }
}
