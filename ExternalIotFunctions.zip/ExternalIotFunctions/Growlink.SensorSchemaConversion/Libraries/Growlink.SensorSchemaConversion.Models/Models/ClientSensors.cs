﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class ClientSensors
    {
        [JsonProperty("clientId")]
        public string OrganizationId { get; set; }
        [JsonProperty("baseStationId")]
        public string BaseStationId { get; set; }

        [JsonProperty("sensorId")]
        public string Sensors { get; set; }
    }
}
