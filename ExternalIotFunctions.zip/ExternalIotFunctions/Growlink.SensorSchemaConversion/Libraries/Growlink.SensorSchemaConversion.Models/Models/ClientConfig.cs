﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class ClientConfig
    {
        [JsonProperty("apiKey")]
        public string APIKey { get; set; }
        [JsonProperty("clientId")]
        public Guid ClientId { get; set; }
        [JsonProperty("clientName")]
        public string ClientName { get; set; }
    }
}
