﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Models.Models
{
    public class Sensors
    {
        [JsonProperty("sensors")]
        public List<Sensor> SensorDetails { get; set; } = new List<Sensor>();
    }

    public class Sensor
    {
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("sensorId")]
        public string SensorId { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("bases")]
        public List<string> Bases { get; set; }
    }

}
