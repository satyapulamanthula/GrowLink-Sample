﻿using Growlink.SensorSchemaConversion.Common.Enums;
using Growlink.SensorSchemaConversion.Models.Models;
using Growlink.SensorSchemaConversion.Services.Interfaces;
using Growlink.SensorSchemaConversion.Services.Services;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Growlink.SensorSchemaConversion.Tests
{
    public class SensorSchemaConversionServiceTest
    {

        //private readonly IClientConfigService ClientConfigService;
        [Fact]
        public void TranslateSensorData_ShouldTranslateBasicData()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" } 
                    },
                    new Sensor
                    {
                        Id = "6293181",
                        SensorId = "006BD",
                        Name = "Table 1",
                        Type = "S6V4",
                        Bases = new List<string> { "358151005625" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029834,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 84
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -94
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Single(data);

            var firstItem = data[0];

            // Assert properties of the first element
            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("2024-09-22 18:30:34", (string)firstItem.ts);
            Assert.Equal(84, (int)firstItem.a1);
            Assert.Equal(255, (int)firstItem.am1);
            Assert.Equal(4, (int)firstItem.au1);
            Assert.Equal(-94, (int)firstItem.a2);
            Assert.Equal(255, (int)firstItem.am2);
            Assert.Equal(255, (int)firstItem.au2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleMultipleSensorGroups()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }  
                    },
                    new Sensor
                    {
                        Id = "6293181",
                        SensorId = "006BD",
                        Name = "Table 1",
                        Type = "S6V4",
                        Bases = new List<string> { "358151005625" }
                    }
                }
            };

            var sensorDataGroup = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029895,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 84
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -93
                },
                new SensorData
                {
                    BaseTime = 1727029955,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 84
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -97
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataGroup, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataGroup);

            // Assert
            Assert.NotNull(data);

            var firstItem = data[0];
            var secondItem = data[1];

            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("2024-09-22 18:31:35", (string)firstItem.ts);
            Assert.Equal(84, (int)firstItem.a1);
            Assert.Equal(255, (int)firstItem.am1);
            Assert.Equal(4, (int)firstItem.au1);
            Assert.Equal(-93, (int)firstItem.a2);
            Assert.Equal(255, (int)firstItem.am2);
            Assert.Equal(255, (int)firstItem.au2);

            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)secondItem.id);
            Assert.Equal("01171", (string)secondItem.sn);
            Assert.Equal("2024-09-22 18:32:35", (string)secondItem.ts);
            Assert.Equal(84, (int)secondItem.a1);
            Assert.Equal(255, (int)secondItem.am1);
            Assert.Equal(4, (int)secondItem.au1);
            Assert.Equal(-97, (int)secondItem.a2);
            Assert.Equal(255, (int)secondItem.am2);
            Assert.Equal(255, (int)secondItem.au2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleNullBaseTime()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    },
                    new Sensor
                    {
                        Id = "6293181",
                        SensorId = "006BD",
                        Name = "Table 1",
                        Type = "S6V4",
                        Bases = new List<string> { "358151005625" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = null,
                    Name = "Temperature",
                    Unit = "Celsius",
                    Value = 25.5M
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -97
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Single(data);

            var firstItem = data[0];

            // Assert the properties of the first item in the result
            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("0001-01-01 00:00:00", (string)firstItem.ts);
            Assert.Equal(25.5M, (decimal)firstItem.a1);
            Assert.Equal(-97, (int)firstItem.a2);
        }

        [Fact]
        public void TranslateSensorData_ShouldTranslateEnumsCorrectly()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727030072,
                    Name = "Temperature",
                    Unit = "cel",
                    Value = 25.5M
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -97
                }
            };
            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Single(data);

            var firstItem = data[0];

            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("2024-09-22 18:34:32", (string)firstItem.ts);
            Assert.Equal(25.5M, (decimal)firstItem.a1);

            Assert.Equal((int)UnitOfMeasures.Celsius, (int)firstItem.au1);
            Assert.Equal((int)DataMetrics.Temperature, (int)firstItem.am1);

            Assert.Equal(-97, (int)firstItem.a2);
            Assert.Equal((int)UnitOfMeasures.None, (int)firstItem.au2);
            Assert.Equal((int)DataMetrics.None, (int)firstItem.am2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleEmptySensorDataList()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>();

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Empty(data);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleMultipleSensorsInOneGroup()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataGroup = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029895,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 84
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -93
                },
                new SensorData
                {
                    BaseTime = 1727029955,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = -84
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -97
                },
                new SensorData
                {
                    BaseTime = 1727030072,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 64
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -97
                }
            };
            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataGroup, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataGroup);

            // Assert
            Assert.NotNull(data);
            Assert.Equal(3, data.Count);

            var firstItem = data[0];
            var secondItem = data[1];
            var thirdItem = data[2];

            Assert.Equal(84, (int)firstItem.a1);
            Assert.Equal(-93, (int)firstItem.a2);

            Assert.Equal(-84, (int)secondItem.a1);
            Assert.Equal(-97, (int)secondItem.a2);

            Assert.Equal(64, (int)thirdItem.a1);
            Assert.Equal(-97, (int)thirdItem.a2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleNullUnitAndName()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029834,
                    Name = null,
                    Unit = null,
                    Value = 84
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Single(data);

            var firstItem = data[0];


            Assert.Null((string)firstItem.n);
            Assert.Null((string)firstItem.u);
            Assert.Equal(84, (int)firstItem.a1);
            Assert.Equal("2024-09-22 18:30:34", (string)firstItem.ts);
            Assert.Equal("358151005624", (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal(255, (int)firstItem.am1);
            Assert.Equal(255, (int)firstItem.au1);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleNullNameAndUnitInSecondObject()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029834,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 84
                },
                new SensorData
                {
                    Name = null,  // Null Name
                    Unit = null,  // Null Unit
                    Value = 56.6M
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);

            var firstItem = data[0];

            Assert.Equal(255, (int)firstItem.am1);
            Assert.Equal(4, (int)firstItem.au1);
            Assert.Equal(84.0M, (decimal)firstItem.a1);

            Assert.Null((string)firstItem.n2);
            Assert.Null((string)firstItem.u2);
            Assert.Equal(56.6M, (decimal)firstItem.a2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleEmptyStrings()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029834,
                    Name = "",  // Empty Name
                    Unit = "",  // Empty Unit
                    Value = 100
                },
                new SensorData
                {
                    Name = "",  // Empty Name
                    Unit = "",  // Empty Unit
                    Value = -99
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            var firstItem = data[0];

            Assert.Equal(255, (int)firstItem.am1);
            Assert.Equal(255, (int)firstItem.au1);
            Assert.Equal(100, (int)firstItem.a1);

            Assert.Equal(255, (int)firstItem.am2);
            Assert.Equal(255, (int)firstItem.au2);
            Assert.Equal(-99, (int)firstItem.a2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleOutOfRangeValues()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = 1727029834,
                    Name = "batteryvoltage",
                    Unit = "%",
                    Value = 1000000  // high value
                },
                new SensorData
                {
                    Name = "rssi",
                    Unit = "dBW",
                    Value = -99999  // low value
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            var firstItem = data[0];

            Assert.Equal(1000000, (int)firstItem.a1);
            Assert.Equal(-99999, (int)firstItem.a2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleNullBaseTimeAndName()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var sensorDataList = new List<SensorData>
            {
                new SensorData
                {
                    BaseName = "aranet:101171:",
                    BaseTime = null,
                    Name = "",
                    Unit = "%",
                    Value = 84
                }
            };

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            var firstItem = data[0];
            
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("0001-01-01 00:00:00", (string)firstItem.ts);
            Assert.Equal(255, (int)firstItem.am1);
            Assert.Equal(4, (int)firstItem.au1);
            Assert.Equal(84, (int)firstItem.a1);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleDeserializedJsonData()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    }
                }
            };

            var jsonData = @"
            [
                  {
                    ""bn"": ""aranet:101171:"",
                    ""bt"": 1727116208,
                    ""n"": ""humidity"",
                    ""u"": ""%RH"",
                    ""v"": 58.8
                  },
                  {
                    ""n"": ""temperature"",
                    ""u"": ""Cel"",
                    ""v"": 20.1
                  }
            ]";

            // Deserialize JSON to List<SensorData>
            var sensorDataList = JsonConvert.DeserializeObject<List<SensorData>>(jsonData);

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Equal(1, data.Count);

            var firstItem = data[0];
            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("2024-09-23 18:30:08", (string)firstItem.ts);
            Assert.Equal(58.8, (double)firstItem.a1);
            Assert.Equal(1, (int)firstItem.am1);
            Assert.Equal(4, (int)firstItem.au1);
            Assert.Equal(20.1, (double)firstItem.a2);
            Assert.Equal(0, (int)firstItem.am2);
            Assert.Equal(0, (int)firstItem.au2);
        }

        [Fact]
        public void TranslateSensorData_ShouldHandleDeserializedMultipleJsonData()
        {
            // Arrange
            var sensorObject = new Sensors
            {
                SensorDetails = new List<Sensor>
                {
                    new Sensor
                    {
                        Id = "1053041",
                        SensorId = "01171",
                        Name = "Room temperature sensor",
                        Type = "S1V17",
                        Bases = new List<string> { "358151005624" }
                    },
                    new Sensor
                    {
                        Id = "6293181",
                        SensorId = "006BD",
                        Name = "Table 1",
                        Type = "S6V4",
                        Bases = new List<string> { "358151005625" }
                    }
                }
            };

            var jsonData = @"
            [
              {
                ""bn"": ""aranet:101171:"",
                ""bt"": 1727116208,
                ""n"": ""humidity"",
                ""u"": ""%RH"",
                ""v"": 58.8
              },
              {
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""bt"": 1727116208,
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""bn"": ""aranet:6006BD:"",
                ""bt"": 1727116208,
                ""n"": ""humidity"",
                ""u"": ""%RH"",
                ""v"": 58.8
              },
              {
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              },
              {
                ""bt"": 1727116208,
                ""n"": ""temperature"",
                ""u"": ""Cel"",
                ""v"": 20.1
              }
            ]";

            // Deserialize JSON data
            var sensorDataList = JsonConvert.DeserializeObject<List<SensorData>>(jsonData);

            string clientId = "wxp4s4f3zqfnfbpq57mu6jcbnzqhch6h";

            // Act
            var loggerMock = Substitute.For<ILogger<SensorSchemaConversionService>>();
            var baseDataServiceMock = Substitute.For<IBaseDataService>();
            var clientConfigServiceMock = Substitute.For<IClientConfigService>();
            List<ClientSensors> avaliableSensorsData = new List<ClientSensors>();
            SensorSchemaConversionService result = new SensorSchemaConversionService(loggerMock, baseDataServiceMock, clientConfigServiceMock);
            var BuildSensordata = result.BuildSensorObject(sensorObject, clientId, sensorDataList, avaliableSensorsData);
            dynamic data = result.TranslateSensorData(sensorObject, sensorDataList);

            // Assert
            Assert.NotNull(data);
            Assert.Equal(4, data.Count);

            var firstItem = data[0];
            var secondItem = data[1];
            var thireItem = data[2];
            var fourthItem = data[3];

            // First group assertions
            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)firstItem.id);
            Assert.Equal("01171", (string)firstItem.sn);
            Assert.Equal("2024-09-23 18:30:08", (string)firstItem.ts);
            Assert.Equal(sensorDataList[0].Value, (decimal)firstItem.a1);
            Assert.Equal(1, (int)firstItem.am1);
            Assert.Equal(4, (int)firstItem.au1);
            Assert.Equal(sensorDataList[1].Value, (decimal)firstItem.a2);
            Assert.Equal(0, (int)firstItem.am2);
            Assert.Equal(0, (int)firstItem.au2);
            Assert.Equal(sensorDataList[2].Value, (decimal)firstItem.a3);
            Assert.Equal(0, (int)firstItem.am3);
            Assert.Equal(0, (int)firstItem.au3);
            Assert.Equal(sensorDataList[3].Value, (decimal)firstItem.a4);
            Assert.Equal(0, (int)firstItem.am4);
            Assert.Equal(0, (int)firstItem.au4);

            Assert.Equal(sensorObject.SensorDetails[0].Bases[0], (string)secondItem.id);
            Assert.Equal("01171", (string)secondItem.sn);
            Assert.Equal("2024-09-23 18:30:08", (string)secondItem.ts);
            Assert.Equal(sensorDataList[4].Value, (decimal)secondItem.a1);
            Assert.Equal(0, (int)secondItem.am1);
            Assert.Equal(0, (int)secondItem.au1);

            Assert.Equal(sensorObject.SensorDetails[1].Bases[0], (string)thireItem.id);
            Assert.Equal("006BD", (string)thireItem.sn);
            Assert.Equal("2024-09-23 18:30:08", (string)thireItem.ts);
            Assert.Equal(sensorDataList[5].Value, (decimal)thireItem.a1);
            Assert.Equal(1, (int)thireItem.am1);
            Assert.Equal(4, (int)thireItem.au1);
            Assert.Equal(sensorDataList[6].Value, (decimal)thireItem.a2);
            Assert.Equal(0, (int)thireItem.am2);
            Assert.Equal(0, (int)thireItem.au2);
            Assert.Equal(sensorDataList[7].Value, (decimal)thireItem.a3);
            Assert.Equal(0, (int)thireItem.am3);
            Assert.Equal(0, (int)thireItem.au3);
            Assert.Equal(sensorDataList[8].Value, (decimal)thireItem.a4);
            Assert.Equal(0, (int)thireItem.am4);
            Assert.Equal(0, (int)thireItem.au4);

            Assert.Equal(sensorObject.SensorDetails[1].Bases[0], (string)fourthItem.id);
            Assert.Equal("006BD", (string)fourthItem.sn);
            Assert.Equal("2024-09-23 18:30:08", (string)fourthItem.ts);
            Assert.Equal(sensorDataList[9].Value, (decimal)fourthItem.a1);
            Assert.Equal(0, (int)fourthItem.am1);
            Assert.Equal(0, (int)fourthItem.au1);
        }
    }
}